# JumpDB

dict/json database python